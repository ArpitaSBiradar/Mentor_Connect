<?php


header("Location: ../");