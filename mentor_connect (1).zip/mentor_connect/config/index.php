<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 6/27/2018
 * Time: 9:13 AM
 */

header("Location: ../");